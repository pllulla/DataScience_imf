a <- 5
b <- 2.0
c <- '5'

# Comentario de una l�nea

"
Comentario de varias l�neas
de
c�digo"

z <- 3

# NOTA: Opci�n de comentar y descomentar varias l�neas de c�digo
# 1. Selecci�n de las l�neas
# 2. Sobre las l�neas seleccionadas: CNTRL + SHIFT + C

# Prueba a comentar/descomentar el siguiente c�digo

funcion.suma <- function(valor_a, valor_b){


  suma <- valor_a + valor_b

  return (suma)
}